const express = require("express");
const router = express.Router();
const Expense = require("../models/Expense");

// ADD EXPENSE
router.post("/", (req, res) => {
  Expense.create(req.body, (err, result) => {
    if (err) return res.status(500).json(err);
    res.status(201).json({ id: result.insertId, ...req.body });
  });
});

// GET ALL EXPENSES
router.get("/", (req, res) => {
  Expense.getAll((err, results) => {
    if (err) return res.status(500).json(err);
    res.status(200).json(results);
  });
});

// UPDATE EXPENSE
router.put("/:id", (req, res) => {
  Expense.update(req.params.id, req.body, (err, result) => {
    if (err) return res.status(500).json(err);
    res.status(200).json({ id: req.params.id, ...req.body });
  });
});

// DELETE EXPENSE
router.delete("/:id", (req, res) => {
  Expense.delete(req.params.id, (err, result) => {
    if (err) return res.status(500).json(err);
    res.status(200).json({ message: "Expense has been successfully deleted" });
  });
});

module.exports = router;
