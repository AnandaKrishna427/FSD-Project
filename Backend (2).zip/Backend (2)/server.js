const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const expenseRoute = require("./routes/expense"); // make sure it's plural now
const db = require("./db"); // our new MySQL db connection

dotenv.config();
const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Routes
app.use("/api/v1/expenses", expenseRoute);

// Test MySQL connection
db.connect((err) => {
  if (err) {
    console.error("Failed to connect to MySQL:", err);
  } else {
    console.log("Connected to MySQL database successfully");
  }
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
