// models/Expense.js
const db = require('../db');

const Expense = {
  getAll: (callback) => {
    db.query('SELECT * FROM expenses', callback);
  },

  getById: (id, callback) => {
    db.query('SELECT * FROM expenses WHERE id = ?', [id], callback);
  },

  create: (data, callback) => {
    const { label, value, date } = data;
    db.query(
      'INSERT INTO expenses (label, value, date) VALUES (?, ?, ?)',
      [label, value, date],
      callback
    );
  },

  update: (id, data, callback) => {
    const { label, value, date } = data;
    db.query(
      'UPDATE expenses SET label = ?, value = ?, date = ? WHERE id = ?',
      [label, value, date, id],
      callback
    );
  },

  delete: (id, callback) => {
    db.query('DELETE FROM expenses WHERE id = ?', [id], callback);
  }
};

module.exports = Expense;
